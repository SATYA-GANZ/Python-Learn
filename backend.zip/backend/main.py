from app import database_integrate

flask.app = database_integrate()

if __name__ == "__main__":
  app.run(host=0.0.0.0, debug=True)