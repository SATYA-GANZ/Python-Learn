from flask import Flask,request

from query import Player

def main_routes():
  
  @app.route("/")
  def index():
    player = Player.query.all()
    return str(player)